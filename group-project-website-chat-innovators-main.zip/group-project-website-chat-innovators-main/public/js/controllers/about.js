document.addEventListener('DOMContentLoaded', function () {
    const spans = document.querySelectorAll('.logo span');

    spans.forEach((span, index) => {
        // Delay each letter appearance by 0.5 seconds times its index
        setTimeout(() => {
            span.style.opacity = 1;
        }, 300 * index);
    });
});

document.addEventListener('DOMContentLoaded', function () {
    var savedTheme = localStorage.getItem('color-scheme') || 'dark'; // Default to 'Dark' if nothing is saved
    document.documentElement.style.colorScheme = savedTheme; // Apply the theme
});