let userId = null;
let chatCounter = 1;
const chats = {'Chat 1': { user: [], urbanquest: [] }};

document.addEventListener('DOMContentLoaded', function () {
    const textarea = document.querySelector("#message-textarea");
    const spans = document.querySelectorAll('.logo span');
    const sendButton = document.getElementById('send-message');
    const messageTextarea = document.getElementById('message-textarea');
    const newChatButton = document.querySelector('.new-chat-button');


    textarea.addEventListener("input", function () {
        textarea.style.height = "50px";
        if (textarea.scrollHeight > textarea.clientHeight) {
            textarea.style.height = "auto";
            textarea.style.height = `${Math.min(textarea.scrollHeight, 300)}px`;
        }
    });
    spans.forEach((span, index) => {
        // Delay each letter appearance by 0.5 seconds times its index
        setTimeout(() => {
            span.style.opacity = 1;
        }, 300 * index);
    });

    sendButton.addEventListener('click', function() {
        if (messageTextarea.value.trim().length > 0) {
            const activeChatLink = document.querySelector('.chat-history li a.active');
            // if (activeChatLink) {
                const activeChatTitle = activeChatLink ? activeChatLink.textContent : 'Chat 1';
                sendMessage(activeChatTitle);
            // }
        } else {
            textarea.style.height = "50px";
            textarea.placeholder = "Message for Urbanquest";
        }
    });

    messageTextarea.addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && !e.shiftKey && messageTextarea.value.trim().length > 0) {
            e.preventDefault();
            const activeChatLink = document.querySelector('.chat-history li a.active');
            // if (activeChatLink) {
                const activeChatTitle = activeChatLink ? activeChatLink.textContent : 'Chat 1';
                console.log(activeChatTitle);
                sendMessage(activeChatTitle);
            // }
        }
    });
    


    document.getElementById('loginForm').addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the default form submission
        submitForm(this);
    });

    document.getElementById('settingsForm').addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the default form submission
        saveSettings();
    });
    document.getElementById('signupForm').addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the default form submission

        if (validateSignupForm()) {
            submitFormForSignup(this);
        }
    });

    const applySavedTheme = () => {
        const savedTheme = localStorage.getItem('theme') || 'Light';
        document.getElementById('system_mode').value = savedTheme;
        document.body.className = savedTheme;
    };

    applySavedTheme();

newChatButton.addEventListener('click', function() {
    if (!userId) {
        alert('User is not logged in.');
        return;
    }
    newChat();
    const chatTitle = generateChatTitle();
    addHistoryItem(chatTitle);
    chats[chatTitle] = { user: [], urbanquest: [] };
    console.log(chats);
    loadChat(chatTitle);
    scrollToBottom();    
});


});

function sendMessage(chatTitle) {
    if (!userId) {
        alert('User is not logged in.');
        return;
    }

    const messageTextarea = document.getElementById('message-textarea');
    const messageContainer = document.querySelector('.message-container');
    const logoDiv = document.querySelector('.logo-dr-tech');

    messageContainer.style.display = 'block';
    logoDiv.style.display = 'none';

    var newUserMessageDiv = document.createElement('div');
    newUserMessageDiv.classList.add('message', 'user-message');

    var userInfoDiv = document.createElement('div'); // Container for avatar and name
    userInfoDiv.classList.add('user-info');

    var userAvatar = document.createElement('div');
    userAvatar.textContent = 'UR';
    userAvatar.classList.add('message-avatar');
    userInfoDiv.appendChild(userAvatar);

    var userName = document.createElement('span');
    userName.textContent = 'You';
    userName.classList.add('message-name');
    userInfoDiv.appendChild(userName);

    newUserMessageDiv.appendChild(userInfoDiv);

    var userText = document.createElement('div');
    userText.textContent = messageTextarea.value;
    chats[chatTitle].user.push(messageTextarea.value);
    userText.classList.add('message-text');
    newUserMessageDiv.appendChild(userText);

    messageContainer.appendChild(newUserMessageDiv);

    var newUrbanquestMessageDiv = document.createElement('div');
    newUrbanquestMessageDiv.classList.add('message', 'urbanquest-message');

    var urbanquestInfoDiv = document.createElement('div'); // Container for avatar and name
    urbanquestInfoDiv.classList.add('urbanquest-info');

    var urbanquestAvatar = document.createElement('div');
    urbanquestAvatar.textContent = 'UQ';
    urbanquestAvatar.classList.add('message-avatar', 'urbanquest-avatar');
    urbanquestInfoDiv.appendChild(urbanquestAvatar);

    var urbanquestName = document.createElement('span');
    urbanquestName.textContent = 'Urbanquest';
    urbanquestName.classList.add('message-name');
    urbanquestInfoDiv.appendChild(urbanquestName);

    newUrbanquestMessageDiv.appendChild(urbanquestInfoDiv);

    var urbanquestText = document.createElement('div');
    urbanquestText.innerHTML = '<span class="material-symbols-outlined rotating">hourglass_top</span>';
    urbanquestText.classList.add('message-text');
    newUrbanquestMessageDiv.appendChild(urbanquestText);

    messageContainer.appendChild(newUrbanquestMessageDiv);

    var userMessage = messageTextarea.value;

    // Log userId to ensure it is set correctly
    console.log('Sending message with userId:', userId);

    fetch('/chat', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ userId, chatTitle, message: userMessage })
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === "success") {
            urbanquestText.textContent = data.response;
            chats[chatTitle].urbanquest.push(data.response);
        } else {
            urbanquestText.textContent = "Failed to get response.";
        }
    })
    .catch(error => {
        console.error('Error:', error);
        urbanquestText.textContent = "Error fetching response.";
    });

    messageTextarea.value = '';
    messageContainer.scrollTop = messageContainer.scrollHeight;
}

function showLoginModal() {
    var loginModal = document.getElementById("loginModal");
    var signUpModal = document.getElementById("signupModal");
    loginModal.style.display = "block";
    signUpModal.style.display = "none";
    loginModal.classList.add("show");

    var span = document.getElementsByClassName("close-button")[0]; 
    span.onclick = function() {
        loginModal.style.display = "none";
        loginModal.classList.remove("show");
        
    }
    window.onclick = function(event) {
        if (event.target == loginModal) {
            loginModal.style.display = "none";
            loginModal.classList.remove("show");
        }
    }
}

function showSignUpModal() {
    var loginModal = document.getElementById("loginModal");
    var signUpModal = document.getElementById("signupModal");
    loginModal.style.display = "none";
    signUpModal.style.display = "block";
    signUpModal.classList.add("show");

    var closeButtons = document.getElementsByClassName("close-button");
    for (let btn of closeButtons) {
        btn.onclick = function() {
            signUpModal.style.display = "none";
            signUpModal.classList.remove("show");
        }
    }

    window.onclick = function(event) {
        if (event.target === signUpModal) {
            signUpModal.style.display = "none";
            signUpModal.classList.remove("show");
        }
    }
}


function validateSignupForm() {
    const password = document.getElementById('signup-password').value;
    const confirmPassword = document.getElementById('confirm-password').value;

    if (password !== confirmPassword) {
        alert('Passwords do not match!');
        return false; // Prevent form submission
    }

    if (password.length < 8) {
        alert('Password must be at least 8 characters long!');
        return false; // Prevent form submission
    }

    return true; // Allow form submission
}
document.addEventListener('DOMContentLoaded', function () {
    var savedTheme = localStorage.getItem('color-scheme') || 'dark'; // Default to 'Dark' if nothing is saved
    document.getElementById('system_mode').value = savedTheme; // Set the select box to reflect the saved theme
    document.documentElement.style.colorScheme = savedTheme; // Apply the theme
});

function saveSettings() {
    // Get the selected mode from the dropdown
    var selectedMode = document.getElementById('system_mode').value;

    // Apply the mode to the body class
    document.documentElement.style.colorScheme = selectedMode;

    // Optionally, save the preference in localStorage
    localStorage.setItem('color-scheme', selectedMode);

    settingsModal.style.display = 'none';
}



function submitFormForSignup(form) {
    const formData = new FormData(form);
    const url = form.action;
    const method = form.method;
    const data = {};
    formData.forEach((value, key) => { data[key] = value; });

    fetch(url, {
        method: method,
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(data => {
                throw new Error(data.error || 'Network response was not ok');
            });
        }
        return response.json();
    })
    .then(data => {
        if (data.status === "success") { 
            updateUIAfterSignup(data.email); 
            alert("Signup successful! Please login.");
        } else {
            alert("Signup failed: " + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        if (error.message === "User Already Exists. Please Login") {
            alert('User Already Exists. Please Login');
        } else {
            alert('Failed to process the signup: ' + error.message);
        }
    });
}


function submitForm(form) {
    const formData = new FormData(form);
    const url = form.action;
    const method = form.method;
    const data = {};
    formData.forEach((value, key) => { data[key] = value; });

    fetch(url, {
        method: method,
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(data => {
                throw new Error(data.error || 'Network response was not ok');
            });
        }
        return response.json();
    })
    .then(data => {
        if (data.status === "success") {
            userId = data.userId; // Ensure this is being set correctly
            console.log('User ID set:', userId); // Add a log to check userId
            updateUIAfterLogin(data.username, data.email);
            alert("Login successful!");

            // Fetch and display all chats
            fetchChats(userId);
        } else {
            alert("Login failed: " + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        if (error.message === "Invalid Credentials") {
            alert('Password is wrong');
        } else if (error.message === "User does not exist") {
            alert('User does not exist');
        } else {
            alert('Failed to parse the response: ' + error.message);
        }
    });
}


function fetchChats(userId) {
    fetch(`/getChats?userId=${userId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.status === "success") {
                const chatsList = data.chats;

                // If no chats found, initialize with "Chat 1"
                if (chatsList.length === 0) {
                    addHistoryItem('Chat 1');
                    chats['Chat 1'] = { user: [], urbanquest: [] };
                    chatCounter = 1;
                } else {
                    chatsList.forEach(chat => {
                        addHistoryItem(chat.chatTitle);
                        chats[chat.chatTitle] = { user: [], urbanquest: [] }; // Initialize the chat in the chats object
                    });

                    // Update chatCounter to the highest chat number
                    const chatNumbers = chatsList.map(chat => {
                        const match = chat.chatTitle.match(/\d+$/);
                        return match ? parseInt(match[0], 10) : 0;
                    });
                    chatCounter = Math.max(...chatNumbers);
                }
            } else {
                console.error("Failed to fetch chats: ", data.message);
            }
        })
        .catch(error => {
            console.error('Error fetching chats:', error);
        });
}



function loadChat(chatTitle) {
    const messageContainer = document.querySelector('.message-container');
    const logoDiv = document.querySelector('.logo-dr-tech');
    messageContainer.innerHTML = '';
    scrollToBottom()

    fetch(`/getMessages?chatTitle=${chatTitle}&userId=${userId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.status === "success") {
                const messages = data.messages;
                if (messages.length === 0) {
                    logoDiv.style.display = 'block';
                    messageContainer.style.display = 'none';
                    return;
                } else {
                    logoDiv.style.display = 'none';
                    messageContainer.style.display = 'block';
                }

                messageContainer.innerHTML = ''; // Clear existing messages

                messages.forEach(message => {
                    if (message.sender === 'user') {
                        const newUserMessageDiv = document.createElement('div');
                        newUserMessageDiv.classList.add('message', 'user-message');

                        const userInfoDiv = document.createElement('div'); // Container for avatar and name
                        userInfoDiv.classList.add('user-info');

                        const userAvatar = document.createElement('div');
                        userAvatar.textContent = 'UR';
                        userAvatar.classList.add('message-avatar');
                        userInfoDiv.appendChild(userAvatar);

                        const userName = document.createElement('span');
                        userName.textContent = 'You';
                        userName.classList.add('message-name');
                        userInfoDiv.appendChild(userName);

                        newUserMessageDiv.appendChild(userInfoDiv);

                        const userText = document.createElement('div');
                        userText.textContent = message.text;
                        userText.classList.add('message-text');
                        newUserMessageDiv.appendChild(userText);

                        messageContainer.appendChild(newUserMessageDiv);
                    } else if (message.sender === 'urbanquest') {
                        const newUrbanquestMessageDiv = document.createElement('div');
                        newUrbanquestMessageDiv.classList.add('message', 'urbanquest-message');

                        const urbanquestInfoDiv = document.createElement('div'); // Container for avatar and name
                        urbanquestInfoDiv.classList.add('urbanquest-info');

                        const urbanquestAvatar = document.createElement('div');
                        urbanquestAvatar.textContent = 'UQ';
                        urbanquestAvatar.classList.add('message-avatar', 'urbanquest-avatar');
                        urbanquestInfoDiv.appendChild(urbanquestAvatar);

                        const urbanquestName = document.createElement('span');
                        urbanquestName.textContent = 'Urbanquest';
                        urbanquestName.classList.add('message-name');
                        urbanquestInfoDiv.appendChild(urbanquestName);

                        newUrbanquestMessageDiv.appendChild(urbanquestInfoDiv);

                        const urbanquestText = document.createElement('div');
                        urbanquestText.classList.add('message-text');
                        urbanquestText.textContent = message.text;
                        newUrbanquestMessageDiv.appendChild(urbanquestText);

                        messageContainer.appendChild(newUrbanquestMessageDiv);
                    }
                });
            } else {
                console.error('Failed to fetch messages: ', data.message);
            }
        })
        .catch(error => {
            console.error('Error fetching messages:', error);
        });
}


function updateUIAfterLogin(username, email) {
    // Hide login related elements
    var loginSection = document.querySelector('.login');
    loginSection.style.display = "none";

    // Update the icon and button for logout
    const userIcon = loginSection.querySelector('i.fa-user');
    userIcon.className = 'fa-solid fa-right-from-bracket';  // Change icon to logout

    const loginButton = loginSection.querySelector('button.hero-button');
    loginButton.textContent = 'Logout';  // Change button text to Logout
    loginButton.onclick = logout;  // Assign logout function to onclick event

    // Display username and email in the settings modal
    const settingsModal = document.getElementById('settingsModal');
    settingsModal.querySelector('#user').value = username;
    settingsModal.querySelector('#email').value = email;
}

function logout() {

    alert('You have been logged out!');
    var loginSection = document.querySelector('.login');
    var messageContainer = document.querySelector('.message-container');
    var logoDiv = document.querySelector('.logo-dr-tech');
    loginSection.style.display = "block";
    var chatHistoryList = document.getElementById('chatHistoryList');

    const userIcon = loginSection.querySelector('i.fa-right-from-bracket');
    userIcon.className = 'fa-solid fa-user';  // Change back to login icon

    const logoutButton = loginSection.querySelector('button.hero-button');
    logoutButton.textContent = 'Login';  // Change text back to Login
    logoutButton.onclick = showLoginModal;  // Reassign showLoginModal function to onclick

    // Clear user-specific data
    const settingsModal = document.getElementById('settingsModal');
    settingsModal.querySelector('#user').value = '';
    settingsModal.querySelector('#email').value = '';

    // Hide settings modal if needed
    settingsModal.style.display = 'none';

    userId = null;
    messageContainer.style.display = 'none';
    logoDiv.style.display = 'block'; 
    
    while (chatHistoryList.firstChild) {
        chatHistoryList.removeChild(chatHistoryList.firstChild);
    }

    

    const newItem = document.createElement('li');
    const link = document.createElement('a');
    link.href = '#';
    link.textContent = "Chat 1";
    newItem.appendChild(link);
    chatHistoryList.appendChild(newItem);

    // Add click event listener to the link
    link.addEventListener('click', function (event) {
        event.preventDefault();
        const allLinks = document.querySelectorAll('.chat-history li a');
        allLinks.forEach(link => link.classList.remove('active'));

        // Add 'active' class to the clicked link
        link.classList.add('active');
    });
}

function updateUIAfterLogin(username, email) {
    // Hide login related elements
    var loginSection = document.querySelector('.login');

    // Update the icon and button for logout
    const icon = document.getElementById('toggleIcon');
    icon.classList.remove('fa-user');
    icon.classList.add('fa-right-from-bracket');

    const loginModal = document.getElementById('loginModal');
    loginModal.style.display = 'none';

    const loginButton = loginSection.querySelector('.hero-button');
    loginButton.textContent = 'Logout';  // Change button text to Logout
    loginButton.onclick = logout;  // Assign logout function to onclick event

    // Display username and email in the settings modal
    const settingsModal = document.getElementById('settingsModal');
    settingsModal.querySelector('#user').value = username;
    settingsModal.querySelector('#email').value = email;

}



function updateUIAfterSignup(email) {
    // Hide the signup modal
    const signupModal = document.getElementById('signupModal');
    if (signupModal) {
        signupModal.style.display = 'none';
    } else {
        console.error('Signup modal element is missing.');
    }

    // Show the login modal
    const loginModal = document.getElementById('loginModal');
    if (loginModal) {
        loginModal.style.display = 'block';
        loginModal.querySelector('#user-email').value = email;
    } else {
        console.error('Login modal element is missing.');
    }
}


function addHistoryItem(text) {
    const chatHistoryList = document.getElementById('chatHistoryList');
    const newItem = document.createElement('li');
    const link = document.createElement('a');
    link.href = '#';
    link.textContent = text;
    newItem.appendChild(link);
    chatHistoryList.appendChild(newItem);

    // Add click event listener to the link
    link.addEventListener('click', function (event) {
        event.preventDefault();
        const allLinks = document.querySelectorAll('.chat-history li a');
        allLinks.forEach(link => link.classList.remove('active'));

        // Add 'active' class to the clicked link
        link.classList.add('active');
        loadChat(text);
    });
    chatHistoryList.appendChild(newItem);

    const activeLink = document.querySelector('.chat-history li a.active');
    if (activeLink) {
        activeLink.classList.remove('active');
    }
    link.classList.add('active');
}

function showSettingModal() {
    var settingsModal = document.getElementById('settingsModal');
    var closeBtn = document.getElementsByClassName('go-back')[0];
    var span = document.getElementsByClassName("close-button")[2];
    settingsModal.classList.add("show");

    span.onclick = function() {
        settingsModal.style.display = "none";
        settingsModal.classList.remove("show");
    }

    settingsModal.style.display = 'block';
    
    closeBtn.onclick = function() {
        settingsModal.style.display = 'none';
        settingsModal.classList.remove("show");
    }

    window.onclick = function(event) {
        if (event.target == settingsModal) {
            settingsModal.style.display = 'none';
            settingsModal.classList.remove("show");
        }
    }
}

function scrollToBottom() {
    const chatHistory = document.querySelector('.chat-history');
    chatHistory.scrollTop = chatHistory.scrollHeight;
}


function generateChatTitle() {
    return `Chat ${chatCounter}`;
}

function newChat() {
    const messageTextarea = document.getElementById('message-textarea');
    messageTextarea.style.height = "50px";
    messageTextarea.value = '';
    chatCounter++;
}